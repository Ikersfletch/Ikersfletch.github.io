var p;
var newb = 0;
function setup() {
  createCanvas(360,360);
  p = createGraphics(360,360,WEBGL);
}
function draw() {

  
  d3d();
  push();
  translate(0,sin(frameCount/100)*100);
  fill(255,0,0);
  rect(0,100,400,10);
  pop();
}
function d3d() {
  newb++;
  //p.strokeWeight(3);
  p.background(255,255,255);
  p.rotateY(1*(PI/180));
  p.rotateX(1*(PI/180));
    //p.translate(this.x,this.y,this.z+1);
    //p.rotateZ(-rc*(PI/180)-(HALF_PI));
    p.push();
    p.scale(1,1,0);
    p.fill(0,0,0);
    p.noStroke();
    p.torus(15,2);
    p.noFill();
    p.strokeWeight(4);
    p.stroke(255,255,255);
    p.arc(0,0,30,30,0,(PI+(newb*(PI/180)))%(2*PI));
    p.pop();
    p.strokeWeight(1);
  p.noStroke();
    p.push();
    p.fill(255,0,0);
    //p.translate(this.x,this.y,this.z+15+s*5+sin(this.a/4)*2);
    //p.rotateZ(-this.r*(PI/180));
    p.rotateX(90*(PI/180));
    p.cone(10,30); // the shirt
    p.fill(100,75,50);
    p.translate(0,10,0);
    p.sphere(10); // the head
    p.push(); // the eyes
    p.stroke(255,255,255);
    p.translate(0,0,10);
    p.fill(0,0,0);
    p.ellipse(-3.5,0,4,6);
    p.ellipse(3.5,0,4,6);
    p.pop();
    p.pop();
  
  image(p,0,0);
}